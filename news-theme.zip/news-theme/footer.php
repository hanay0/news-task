</div>
    <footer class="footer text-center py-2">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <p class="copyright m-0">
                        All Rights are reserved for
                        <a class="font-weight-bold text-danger" href="https://code95.com">Code95</a>
                    </p>
                </div>
            </div>
        </div>
    </footer>
    
    <?php
        wp_footer();
    ?>

</body>
</html> 