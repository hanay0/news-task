<?php
get_header();
?>

    <div class="container">
        <div class="col-md-12">
            <div class="block d-flex flex-column align-items-center">
                <h2 style="font-size: 94px">!404</h2>
                <h1 class="text-warning">This page is not existed</h1>
            </div>
        </div>
    
    </div>

<?php
get_footer();
?>